# ⚡ GridSense AI

## Smart Grid Load Forecasting & Anomaly Detection Platform

GridSense AI is an end-to-end machine learning platform for **electricity demand forecasting, smart-grid telemetry analytics, renewable-generation analysis, and operational anomaly detection**.

The project combines time-series feature engineering, gradient-boosting forecasting, unsupervised anomaly detection, interactive business intelligence, and a REST API.

---

## 🚀 Key Features

- ⚡ Hourly electricity load forecasting
- 📈 Time-series feature engineering
- 🤖 HistGradientBoosting demand model
- 🚨 Isolation Forest anomaly detection
- 🛡️ Grid frequency and voltage monitoring
- ☀️ Renewable-generation analytics
- 🌡️ Weather-to-load relationship analysis
- 📊 Interactive Streamlit dashboard
- 🌐 Flask REST API
- 📋 Model performance reporting
- 🔄 Chronological train/test evaluation

---

## 🧠 Machine Learning Architecture

```text
Smart Grid Telemetry
        │
        ├── Load
        ├── Temperature
        ├── Humidity
        ├── Solar Irradiance
        ├── Renewable Generation
        ├── Voltage
        └── Frequency
                │
                ▼
        Feature Engineering
                │
        ┌───────┴────────┐
        ▼                ▼
 Load Forecasting   Anomaly Detection
        │                │
        ▼                ▼
 Future Demand     Grid Health Alerts
        │                │
        └───────┬────────┘
                ▼
        Streamlit Dashboard
                │
                ▼
             REST API
```

---

## 📊 Dataset

The project contains **17,544 hourly synthetic smart-grid observations** covering two years.

Features include:

- Temperature
- Humidity
- Solar irradiance
- Renewable generation
- Grid frequency
- Transmission voltage
- Electricity load
- Injected operational anomalies

The data is completely synthetic and is intended for portfolio and educational use.

---

## 🤖 Forecasting Model

### HistGradientBoostingRegressor

The forecasting model uses:

- 1-hour demand lag
- 24-hour demand lag
- 168-hour demand lag
- 24-hour rolling demand
- 168-hour rolling demand
- temperature
- humidity
- renewable generation
- solar irradiance
- voltage
- frequency
- cyclic hour features
- cyclic annual features
- temperature stress
- renewable share
- frequency deviation

### Evaluation

A **chronological 60-day holdout** is used instead of random splitting.

| Metric | Result |
|---|---:|
| MAE | 22.16 MW |
| RMSE | 28.65 MW |
| R² | 0.9681 |

---

## 🚨 Anomaly Detection

GridSense AI uses **Isolation Forest** to identify unusual operational patterns involving:

- Electricity load
- Grid frequency
- Voltage
- Temperature
- Renewable generation

This provides an unsupervised anomaly-detection layer independent of the forecasting model.

---

## 🖥️ Dashboard

The Streamlit dashboard includes:

### Load Analytics
- Hourly demand trends
- Peak load
- Average load
- Demand vs renewable generation

### Environmental Analytics
- Temperature vs demand
- Solar irradiance
- Renewable generation

### Grid Health
- Frequency monitoring
- Voltage monitoring
- Operational anomaly table

### Model Monitoring
- MAE
- RMSE
- R²
- Forecasting test-period results

---

## ⚙️ Installation

```bash
git clone https://github.com/YOUR_USERNAME/GridSense-AI.git
cd GridSense-AI
pip install -r requirements.txt
```

---

## ▶️ Run Dashboard

```bash
streamlit run app.py
```

---

## 🌐 Run REST API

```bash
python api.py
```

Health check:

```http
GET /health
```

Forecast endpoint:

```http
POST /forecast
```

Example request:

```json
{
  "historical_data": [
    {
      "timestamp": "2025-12-31 23:00:00",
      "temperature_c": 22.5,
      "humidity_pct": 60,
      "solar_irradiance_wm2": 0,
      "renewable_generation_mw": 0,
      "grid_frequency_hz": 50.01,
      "voltage_kv": 220,
      "load_mw": 920
    }
  ]
}
```

The API expects sufficient historical observations to calculate the lag and rolling features.

---

## 📁 Project Structure

```text
GridSense_AI/
│
├── data/
│   └── smart_grid_data.csv
│
├── models/
│   ├── load_forecasting_model.joblib
│   └── grid_anomaly_detector.joblib
│
├── reports/
│   ├── metrics.json
│   ├── project_summary.md
│   └── sample_forecast_input.json
│
├── src/
│   ├── __init__.py
│   ├── features.py
│   ├── train.py
│   ├── predict.py
│   └── anomaly.py
│
├── notebooks/
│   └── README.md
│
├── app.py
├── api.py
├── requirements.txt
└── README.md
```

---

## 💼 Potential Applications

- Utility demand forecasting
- Grid planning
- Peak-load management
- Renewable integration
- Smart-meter analytics
- Energy trading analytics
- Grid-health monitoring
- Predictive maintenance research
- Energy management systems

---

## 🔮 Future Enhancements

- XGBoost / LightGBM comparison
- LSTM / Temporal Fusion Transformer
- Probabilistic load forecasting
- Real-time Kafka ingestion
- Weather API integration
- SCADA integration
- PostgreSQL data warehouse
- Docker deployment
- Cloud deployment
- MLflow experiment tracking
- Automated model retraining
- SHAP explainability
- Alerting through email/SMS
- Digital-twin simulation

---

## ⚠️ Disclaimer

This project uses synthetic data and is intended for **educational, research, and portfolio demonstration purposes**. It must not be used for real-time grid control or operational decisions without proper validation and engineering oversight.

---

## 👨‍💻 Author

**Snehil Raj**

B.Tech Electrical & Electronics Engineering

Areas:
- Machine Learning
- Data Analytics
- Energy Analytics
- Smart Grids
- AI
- Business Analytics

⭐ Star the repository if you find the project useful.
