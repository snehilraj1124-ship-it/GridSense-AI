from flask import Flask, jsonify, request
import joblib
import pandas as pd


app = Flask(__name__)

MODEL_PATH = "models/load_forecasting_model.joblib"


@app.get("/health")
def health():
    return jsonify({
        "status": "ok",
        "service": "GridSense AI Load Forecasting API"
    })


@app.post("/forecast")
def forecast():
    payload = request.get_json()

    if not payload or "historical_data" not in payload:
        return jsonify({
            "error": "Provide historical_data in JSON payload."
        }), 400

    data = payload["historical_data"]

    if len(data) < 169:
        return jsonify({
            "error": "At least 169 hourly observations are recommended."
        }), 400

    df = pd.DataFrame(data)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df = df.sort_values("timestamp").reset_index(drop=True)

    # Feature engineering
    import numpy as np

    df["hour"] = df["timestamp"].dt.hour
    df["dayofweek"] = df["timestamp"].dt.dayofweek
    df["dayofyear"] = df["timestamp"].dt.dayofyear
    df["month"] = df["timestamp"].dt.month
    df["is_weekend"] = (df["dayofweek"] >= 5).astype(int)

    df["hour_sin"] = np.sin(2 * np.pi * df["hour"] / 24)
    df["hour_cos"] = np.cos(2 * np.pi * df["hour"] / 24)
    df["doy_sin"] = np.sin(2 * np.pi * df["dayofyear"] / 365)
    df["doy_cos"] = np.cos(2 * np.pi * df["dayofyear"] / 365)

    df["load_lag_1h"] = df["load_mw"].shift(1)
    df["load_lag_24h"] = df["load_mw"].shift(24)
    df["load_lag_168h"] = df["load_mw"].shift(168)

    df["rolling_load_24h"] = df["load_mw"].shift(1).rolling(24).mean()
    df["rolling_load_168h"] = df["load_mw"].shift(1).rolling(168).mean()

    df["temperature_load_stress"] = (
        np.maximum(df["temperature_c"] - 27, 0)
        + np.maximum(18 - df["temperature_c"], 0)
    )

    df["renewable_share"] = (
        df["renewable_generation_mw"]
        / (df["load_mw"] + 1)
    )

    df["frequency_deviation"] = (
        abs(df["grid_frequency_hz"] - 50)
    )

    df = df.dropna()

    artifact = joblib.load(MODEL_PATH)

    prediction = artifact["model"].predict(
        df[artifact["features"]]
    )

    return jsonify({
        "forecasted_load_mw": round(
            max(0, float(prediction[-1])), 3
        )
    })


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )
