import json
import joblib
import pandas as pd
import plotly.express as px
import streamlit as st


st.set_page_config(
    page_title="GridSense AI",
    page_icon="⚡",
    layout="wide"
)

st.title("⚡ GridSense AI")
st.caption(
    "Smart Grid Load Forecasting & Anomaly Detection Platform"
)

DATA_PATH = "data/smart_grid_data.csv"

df = pd.read_csv(
    DATA_PATH,
    parse_dates=["timestamp"]
)

metrics = {}
try:
    with open("reports/metrics.json") as f:
        metrics = json.load(f)
except FileNotFoundError:
    pass


# =========================================================
# KPI ROW
# =========================================================

c1, c2, c3, c4 = st.columns(4)

c1.metric(
    "Average Load",
    f"{df['load_mw'].mean():,.1f} MW"
)

c2.metric(
    "Peak Load",
    f"{df['load_mw'].max():,.1f} MW"
)

c3.metric(
    "Renewable Generation",
    f"{df['renewable_generation_mw'].mean():,.1f} MW"
)

c4.metric(
    "Detected / Injected Events",
    f"{int(df['anomaly_flag'].sum()):,}"
)


# =========================================================
# SIDEBAR
# =========================================================

st.sidebar.header("Grid Controls")

days = st.sidebar.slider(
    "Historical window (days)",
    min_value=1,
    max_value=60,
    value=14
)

end_date = df["timestamp"].max()
start_date = end_date - pd.Timedelta(days=days)

view = df[
    df["timestamp"].between(start_date, end_date)
].copy()


# =========================================================
# LOAD ANALYTICS
# =========================================================

st.subheader("📈 Grid Load Analytics")

fig = px.line(
    view,
    x="timestamp",
    y="load_mw",
    title="Hourly Electricity Demand"
)

st.plotly_chart(
    fig,
    use_container_width=True
)


# =========================================================
# RENEWABLE VS LOAD
# =========================================================

left, right = st.columns(2)

with left:
    fig2 = px.line(
        view,
        x="timestamp",
        y=["load_mw", "renewable_generation_mw"],
        title="Demand vs Renewable Generation"
    )
    st.plotly_chart(fig2, use_container_width=True)

with right:
    fig3 = px.scatter(
        view.sample(min(2500, len(view))),
        x="temperature_c",
        y="load_mw",
        color="anomaly_flag",
        title="Temperature vs Load"
    )
    st.plotly_chart(fig3, use_container_width=True)


# =========================================================
# GRID HEALTH
# =========================================================

st.subheader("🛡️ Grid Health Indicators")

h1, h2 = st.columns(2)

with h1:
    fig4 = px.line(
        view,
        x="timestamp",
        y="grid_frequency_hz",
        title="Grid Frequency"
    )
    fig4.add_hline(y=50)
    st.plotly_chart(fig4, use_container_width=True)

with h2:
    fig5 = px.line(
        view,
        x="timestamp",
        y="voltage_kv",
        title="Transmission Voltage"
    )
    st.plotly_chart(fig5, use_container_width=True)


# =========================================================
# MODEL PERFORMANCE
# =========================================================

st.subheader("🤖 Forecast Model Performance")

m1, m2, m3 = st.columns(3)

m1.metric("MAE", f"{metrics.get('MAE_MW', 0):.2f} MW")
m2.metric("RMSE", f"{metrics.get('RMSE_MW', 0):.2f} MW")
m3.metric("R²", f"{metrics.get('R2', 0):.4f}")


# =========================================================
# ANOMALIES
# =========================================================

st.subheader("🚨 Operational Anomalies")

anomalies = view[
    view["anomaly_flag"] == 1
]

st.dataframe(
    anomalies[
        [
            "timestamp",
            "load_mw",
            "grid_frequency_hz",
            "voltage_kv",
            "temperature_c"
        ]
    ].tail(100),
    use_container_width=True
)

st.info(
    "Synthetic telemetry is used for portfolio demonstration. "
    "This dashboard is not intended for live grid control."
)
