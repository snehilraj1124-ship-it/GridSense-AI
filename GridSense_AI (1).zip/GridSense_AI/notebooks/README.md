# Notebooks

Recommended future notebooks:

1. `01_eda.ipynb` — Smart-grid exploratory analysis
2. `02_load_forecasting.ipynb` — Model experimentation
3. `03_anomaly_detection.ipynb` — Isolation Forest analysis
4. `04_model_explainability.ipynb` — Feature importance and SHAP
