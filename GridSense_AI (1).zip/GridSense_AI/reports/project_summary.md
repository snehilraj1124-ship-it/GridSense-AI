# GridSense AI — Model Summary

## Dataset
- Hourly smart-grid telemetry
- Records: 17,544
- Period: 2024-01-01 to 2025-12-31
- Synthetic data for portfolio/education

## Load Forecasting
- Model: HistGradientBoostingRegressor
- Chronological holdout: final 60 days
- MAE: 22.1561 MW
- RMSE: 28.6508 MW
- R²: 0.9681

## Anomaly Detection
- Model: Isolation Forest
- Detects unusual combinations of load, frequency, voltage,
  temperature and renewable generation.

## Important
All data is synthetic. Results are demonstrations and should
not be used for operational grid control.
