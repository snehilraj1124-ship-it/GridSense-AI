import joblib
import pandas as pd


MODEL_PATH = "models/grid_anomaly_detector.joblib"


def detect_anomalies(data):
    """Return anomaly predictions and scores for telemetry rows."""

    df = pd.DataFrame(data)

    artifact = joblib.load(MODEL_PATH)

    features = artifact["features"]
    model = artifact["model"]

    df["anomaly_score"] = model.decision_function(df[features])
    df["anomaly"] = (
        model.predict(df[features]) == -1
    ).astype(int)

    return df
