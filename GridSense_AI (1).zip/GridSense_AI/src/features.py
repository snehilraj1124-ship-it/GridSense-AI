import numpy as np
import pandas as pd


def engineer_features(df):
    """Create temporal, load-history and grid-stress features."""

    out = df.copy()
    out["timestamp"] = pd.to_datetime(out["timestamp"])
    out = out.sort_values("timestamp").reset_index(drop=True)

    out["hour"] = out["timestamp"].dt.hour
    out["dayofweek"] = out["timestamp"].dt.dayofweek
    out["dayofyear"] = out["timestamp"].dt.dayofyear
    out["month"] = out["timestamp"].dt.month
    out["is_weekend"] = (out["dayofweek"] >= 5).astype(int)

    out["hour_sin"] = np.sin(2 * np.pi * out["hour"] / 24)
    out["hour_cos"] = np.cos(2 * np.pi * out["hour"] / 24)
    out["doy_sin"] = np.sin(2 * np.pi * out["dayofyear"] / 365)
    out["doy_cos"] = np.cos(2 * np.pi * out["dayofyear"] / 365)

    out["load_lag_1h"] = out["load_mw"].shift(1)
    out["load_lag_24h"] = out["load_mw"].shift(24)
    out["load_lag_168h"] = out["load_mw"].shift(168)

    out["rolling_load_24h"] = (
        out["load_mw"].shift(1).rolling(24).mean()
    )
    out["rolling_load_168h"] = (
        out["load_mw"].shift(1).rolling(168).mean()
    )

    out["temperature_load_stress"] = (
        np.maximum(out["temperature_c"] - 27, 0)
        + np.maximum(18 - out["temperature_c"], 0)
    )

    out["renewable_share"] = (
        out["renewable_generation_mw"]
        / (out["load_mw"] + 1)
    )

    out["frequency_deviation"] = (
        abs(out["grid_frequency_hz"] - 50)
    )

    return out
