import joblib
import pandas as pd

from .features import engineer_features


MODEL_PATH = "models/load_forecasting_model.joblib"


def forecast_load(historical_data):
    """Forecast load for the latest valid historical row."""

    if not historical_data:
        raise ValueError("historical_data cannot be empty")

    df = pd.DataFrame(historical_data)
    engineered = engineer_features(df).dropna().reset_index(drop=True)

    if engineered.empty:
        raise ValueError(
            "At least 169 hourly observations are recommended "
            "to calculate the full lag/rolling feature set."
        )

    artifact = joblib.load(MODEL_PATH)

    prediction = artifact["model"].predict(
        engineered[artifact["features"]]
    )

    return max(0.0, float(prediction[-1]))
