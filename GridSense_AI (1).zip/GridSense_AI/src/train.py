import json
import joblib
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from features import engineer_features


DATA_PATH = "data/smart_grid_data.csv"
MODEL_PATH = "models/load_forecasting_model.joblib"
METRICS_PATH = "reports/metrics.json"

FEATURES = [
    "temperature_c", "humidity_pct", "solar_irradiance_wm2",
    "renewable_generation_mw", "grid_frequency_hz", "voltage_kv",
    "hour", "dayofweek", "dayofyear", "month", "is_weekend",
    "hour_sin", "hour_cos", "doy_sin", "doy_cos",
    "load_lag_1h", "load_lag_24h", "load_lag_168h",
    "rolling_load_24h", "rolling_load_168h",
    "temperature_load_stress", "renewable_share",
    "frequency_deviation"
]

df = pd.read_csv(DATA_PATH, parse_dates=["timestamp"])
df = engineer_features(df).dropna().reset_index(drop=True)

cutoff = df["timestamp"].max() - pd.Timedelta(days=60)

train = df[df["timestamp"] < cutoff]
test = df[df["timestamp"] >= cutoff]

model = HistGradientBoostingRegressor(
    learning_rate=0.07,
    max_iter=300,
    max_leaf_nodes=31,
    l2_regularization=0.5,
    random_state=42
)

model.fit(train[FEATURES], train["load_mw"])

pred = model.predict(test[FEATURES])
pred = pred.clip(min=0)

metrics = {
    "MAE_MW": round(float(mean_absolute_error(test["load_mw"], pred)), 4),
    "RMSE_MW": round(float(mean_squared_error(test["load_mw"], pred) ** 0.5), 4),
    "R2": round(float(r2_score(test["load_mw"], pred)), 4)
}

joblib.dump(
    {"model": model, "features": FEATURES},
    MODEL_PATH,
    compress=5
)

with open(METRICS_PATH, "w") as f:
    json.dump(metrics, f, indent=4)

print(metrics)
